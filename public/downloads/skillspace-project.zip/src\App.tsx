﻿import SkillSpaceLandingPage from './SkillSpaceLandingPage'

export default function App() {
  return <SkillSpaceLandingPage />
}
